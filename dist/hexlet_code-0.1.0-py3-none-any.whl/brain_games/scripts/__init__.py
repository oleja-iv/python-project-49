"""Package with executable scripts."""
__all__ = [
    'brain_games',
    'brain_even',
    'brain_calc',
    'brain_gcd',
    'brain_prime',
    'brain_progression',
]
