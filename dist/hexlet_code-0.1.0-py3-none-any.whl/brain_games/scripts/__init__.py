"""Package with executable scripts."""
__all__ = ('brain_games', )
