#!/usr/bin/env python3

def greet(who):
    print(f'Hello, {who}!')


def welcome_greet():
    print('Welcome to the Brain Games!')


def main():
    welcome_greet()


if __name__ == '__main__':
    main()