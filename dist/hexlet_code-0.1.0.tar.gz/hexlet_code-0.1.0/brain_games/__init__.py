"""Brain_games is a simple command-line game."""
__all__ = ['cli', 'scripts', 'launch', 'games']
