"""Games and its logic."""
__all__ = ['logic', 'even', 'calc', 'gcd', 'progression', 'prime']
