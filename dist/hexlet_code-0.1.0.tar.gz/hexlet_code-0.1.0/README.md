### Hexlet tests and linter status:
[![Actions Status](https://github.com/oleja-iv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/oleja-iv/python-project-49/actions)