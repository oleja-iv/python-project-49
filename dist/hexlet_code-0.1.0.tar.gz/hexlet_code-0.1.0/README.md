### Hexlet tests and linter status:
[![Actions Status](https://github.com/oleja-iv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/oleja-iv/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ada1a855e47817f5994d/maintainability)](https://codeclimate.com/github/oleja-iv/python-project-49/maintainability)